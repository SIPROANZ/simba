@extends('adminlte::page', ['iFrameEnabled' => true])


@section('title', 'Escritorio')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
<br>
    <p>
        HERMANO  ESTAN SERIAN LAS ETIQUETAS DONDE SE COLOCARA EL CONTENIDO
        PAR TODAS LAS PAGINAS DEL CAUSADO
    </p>
    
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
